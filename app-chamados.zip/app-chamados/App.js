import React from 'react';
import { AuthProvider } from './context/AuthContext';
import { ChamadoProvider } from './context/ChamadoContext';
import AppNavigator from './navigation/AppNavigator';

export default function App() {
  return (
    <AuthProvider>
      <ChamadoProvider>
        <AppNavigator />
      </ChamadoProvider>
    </AuthProvider>
  );
}