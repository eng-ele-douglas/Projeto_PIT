import axios from 'axios';

// 🛑 SUBSTITUA PELO IP DA SUA MÁQUINA 🛑
const IP_DA_SUA_API = 'http://localhost:3001'; // Use o seu IP real

const api = axios.create({
  baseURL: `${IP_DA_SUA_API}/api`, // api projeto_chamado
});

export default api;