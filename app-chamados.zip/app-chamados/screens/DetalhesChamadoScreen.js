import React, { useContext, useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator, TextInput, Button, Alert } from 'react-native';
import { ChamadoContext } from '../context/ChamadoContext';
import { AuthContext } from '../context/AuthContext';

const DetalhesChamadoScreen = ({ route }) => {
  const { id_chamado } = route.params;
  const {
	chamadoSelecionado,
	isLoadingSingle,
	error,
	fetchChamadoById,
	addComentario,
	updateStatus,
	limparChamadoSelecionado,
  } = useContext(ChamadoContext);
  const { usuario } = useContext(AuthContext);
  const [novoComentario, setNovoComentario] = useState('');

  useEffect(() => {
	fetchChamadoById(id_chamado);
	return () => {
	  limparChamadoSelecionado();
	};
  }, [id_chamado]);

  const handleAddComentario = async () => {
	if (!novoComentario.trim()) return;
	try {
	  await addComentario(id_chamado, novoComentario);
	  setNovoComentario('');
	} catch (e) {
	  Alert.alert('Erro', e.message);
	}
  };

  const handleUpdateStatus = (novo_status) => {
	Alert.alert(
	  'Confirmar Ação',
	  `Deseja mesmo alterar o status para "${novo_status}"?`,
	  [
		{ text: 'Cancelar' },
		{ text: 'Confirmar', onPress: () => updateStatus(id_chamado, novo_status) },
	  ]
	);
  };

  const renderBotoesTecnico = () => {
	if (usuario?.tipo !== 'tecnico' || !chamadoSelecionado) return null;
	const status = chamadoSelecionado.status;

	return (
	  <View style={styles.botoesTecnico}>
		{status === 'Aberto' && (
		  <Button
			title="Assumir Chamado"
			onPress={() => handleUpdateStatus('Em Andamento')}
			color="#ffc107"
		  />
		)}
		{status === 'Em Andamento' && (
		  <Button
			title="Resolver Chamado"
			onPress={() => handleUpdateStatus('Resolvido')}
			color="#28a745"
		  />
		)}
		{status === 'Resolvido' && (
		   <Button
			title="Reabrir Chamado"
			onPress={() => handleUpdateStatus('Em Andamento')}
			color="#dc3545"
		  />
		)}
	  </View>
	);
  };

  if (isLoadingSingle) {
	return <ActivityIndicator size="large" style={styles.loading} />;
  }
  if (error) {
	return <Text style={styles.errorText}>{error}</Text>;
  }
  if (!chamadoSelecionado) {
	return null;
  }

  return (
	<ScrollView style={styles.container}>
	  <View style={styles.card}>
		<Text style={styles.title}>{chamadoSelecionado.titulo}</Text>
		<Text style={styles.status}>Status: {chamadoSelecionado.status}</Text>
		<Text style={styles.prioridade}>Prioridade: {chamadoSelecionado.prioridade}</Text>
		<Text style={styles.descricao}>{chamadoSelecionado.descricao}</Text>
	  </View>
	  {renderBotoesTecnico()}
	  <View style={styles.card}>
		<Text style={styles.sectionTitle}>Histórico de Comentários</Text>
		{chamadoSelecionado.comentarios.length === 0 ? (
		  <Text style={styles.comentarioTexto}>Nenhum comentário ainda.</Text>
		) : (
		  chamadoSelecionado.comentarios.map((com, index) => (
			<View key={index} style={styles.comentario}>
			  <Text style={styles.comentarioAutor}>{com.nome_usuario}</Text>
			  <Text style={styles.comentarioTexto}>{com.texto}</Text>
			  <Text style={styles.comentarioData}>
				{new Date(com.data_comentario).toLocaleString('pt-BR')}
			  </Text>
			</View>
		  ))
		)}
		<TextInput
		  style={styles.inputComentario}
		  placeholder="Escreva um comentário..."
		  value={novoComentario}
		  onChangeText={setNovoComentario}
		  multiline
		/>
		<Button title="Enviar Comentário" onPress={handleAddComentario} />
	  </View>
	</ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f0f0' },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  errorText: { color: 'red', textAlign: 'center', marginTop: 20 },
  card: { backgroundColor: '#fff', borderRadius: 8, padding: 15, margin: 10 },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 10 },
  status: { fontSize: 16, marginBottom: 5, color: 'blue' },
  prioridade: { fontSize: 16, marginBottom: 10, color: 'orange' },
  descricao: { fontSize: 16, lineHeight: 22, color: '#333' },
  botoesTecnico: { marginHorizontal: 10, marginTop: 5, padding: 10, backgroundColor: '#fff', borderRadius: 8 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 15 },
  comentario: {
	backgroundColor: '#f9f9f9',
	borderRadius: 5,
	padding: 10,
	marginBottom: 10,
	borderWidth: 1,
	borderColor: '#eee',
  },
  comentarioAutor: { fontWeight: 'bold', color: '#0056b3' },
  comentarioTexto: { fontSize: 15 },
  comentarioData: { fontSize: 12, color: 'gray', textAlign: 'right', marginTop: 5 },
  inputComentario: {
	backgroundColor: '#f0f0f0',
	borderWidth: 1,
	borderColor: '#ddd',
	borderRadius: 5,
	padding: 10,
	minHeight: 60,
	marginTop: 10,
	marginBottom: 10,
	textAlignVertical: 'top',
  },
});

export default DetalhesChamadoScreen;