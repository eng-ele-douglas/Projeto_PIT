import React, { useState, useContext } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, ScrollView, ActivityIndicator } from 'react-native';
import { Picker } from '@react-native-picker/picker'; 
import { ChamadoContext } from '../context/ChamadoContext';

const NovoChamadoScreen = ({ navigation }) => {
  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [prioridade, setPrioridade] = useState('Baixa');
  const [isLoading, setIsLoading] = useState(false);
  const { createChamado } = useContext(ChamadoContext);

  const handleSubmit = async () => {
	if (!titulo || !descricao) {
	  Alert.alert('Erro', 'Título e Descrição são obrigatórios.');
	  return;
	}
	setIsLoading(true);
	try {
	  await createChamado(titulo, descricao, prioridade);
	  Alert.alert('Sucesso!', 'Chamado aberto.', [
		{ text: 'OK', onPress: () => navigation.goBack() },
	  ]);
	} catch (error) {
	  Alert.alert('Erro', error.message);
	} finally {
	  setIsLoading(false);
	}
  };

  return (
	<ScrollView style={styles.container}>
	  <Text style={styles.label}>Título do Chamado</Text>
	  <TextInput
		style={styles.input}
		placeholder="Ex: Impressora não funciona"
		value={titulo}
		onChangeText={setTitulo}
	  />
	  <Text style={styles.label}>Descrição Detalhada</Text>
	  <TextInput
		style={[styles.input, styles.textArea]}
		placeholder="Descreva o problema em detalhes..."
		value={descricao}
		onChangeText={setDescricao}
		multiline={true}
		numberOfLines={6}
	  />
	  <Text style={styles.label}>Prioridade</Text>
	  <View style={styles.pickerContainer}>
		<Picker
		  selectedValue={prioridade}
		  onValueChange={(itemValue) => setPrioridade(itemValue)}
		  style={styles.picker}
		>
		  <Picker.Item label="Baixa" value="Baixa" />
		  <Picker.Item label="Média" value="Média" />
		  <Picker.Item label="Alta" value="Alta" />
		</Picker>
	  </View>
	  {isLoading ? (
		<ActivityIndicator size="large" color="#0000ff" />
	  ) : (
		<Button title="Abrir Chamado" onPress={handleSubmit} />
	  )}
	</ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f5f5f5' },
  label: { fontSize: 16, color: '#333', marginBottom: 5, marginTop: 10 },
  input: {
	height: 45,
	backgroundColor: '#fff',
	borderColor: 'gray',
	borderWidth: 1,
	marginBottom: 15,
	padding: 10,
	borderRadius: 5,
  },
  textArea: { height: 120, textAlignVertical: 'top' },
  pickerContainer: {
	backgroundColor: '#fff',
	borderColor: 'gray',
	borderWidth: 1,
	borderRadius: 5,
	marginBottom: 20,
  },
  picker: { height: 50 },
});

export default NovoChamadoScreen;