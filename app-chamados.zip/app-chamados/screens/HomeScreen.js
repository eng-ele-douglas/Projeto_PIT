import React, { useContext, useCallback } from 'react';
import { View, Text, Button, StyleSheet, FlatList, ActivityIndicator, TouchableOpacity } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { AuthContext } from '../context/AuthContext';
import { ChamadoContext } from '../context/ChamadoContext';

const HomeScreen = ({ navigation }) => {
  const { usuario, logout } = useContext(AuthContext);
  const { chamados, isLoading, error, fetchChamados } = useContext(ChamadoContext);

  useFocusEffect(
	useCallback(() => {
	  fetchChamados();
	}, [fetchChamados])
  );

  const renderItem = ({ item }) => (
	<TouchableOpacity 
	  style={styles.chamadoItem}
	  onPress={() => navigation.navigate('DetalhesChamado', { id_chamado: item.id_chamado })}
	>
	  <View style={styles.itemHeader}>
		<Text style={styles.chamadoTitulo}>{item.titulo}</Text>
		<Text style={[styles.chamadoStatus, getStatusStyle(item.status)]}>
		  {item.status}
		</Text>
	  </View>
	  <Text style={styles.chamadoDetalhe}>Solicitante: {item.nome_solicitante}</Text>
	  <Text style={styles.chamadoDetalhe}>Prioridade: {item.prioridade}</Text>
	</TouchableOpacity>
  );

  const renderContent = () => {
	if (isLoading) {
	  return <ActivityIndicator size="large" color="#0000ff" style={styles.loading} />;
	}
	if (error) {
	  return <Text style={styles.errorText}>{error}</Text>;
	}
	if (chamados.length === 0) {
	  return <Text style={styles.emptyText}>Nenhum chamado encontrado.</Text>;
	}
	return (
	  <FlatList
		data={chamados}
		renderItem={renderItem}
		keyExtractor={(item) => item.id_chamado.toString()}
		style={styles.list}
	  />
	);
  };

  return (
	<View style={styles.container}>
	  <View style={styles.header}>
		<Text style={styles.welcome}>Olá, {usuario?.nome}</Text>
		<Button title="Sair" onPress={logout} color="red" />
	  </View>
	  <View style={styles.novoChamadoButton}>
		<Button 
		  title="Abrir Novo Chamado" 
		  onPress={() => navigation.navigate('NovoChamado')} 
		/>
	  </View>
	  {renderContent()}
	</View>
  );
};

const getStatusStyle = (status) => {
  switch (status) {
	case 'Aberto':
	  return { backgroundColor: '#c6e5ff', color: '#0056b3' };
	case 'Em Andamento':
	  return { backgroundColor: '#fff3cd', color: '#856404' };
	case 'Resolvido':
	case 'Fechado':
	  return { backgroundColor: '#d4edda', color: '#155724' };
	default:
	  return { backgroundColor: '#e2e3e5', color: '#383d41' };
  }
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f0f0' },
  header: {
	flexDirection: 'row',
	justifyContent: 'space-between',
	alignItems: 'center',
	padding: 15,
	backgroundColor: '#fff',
	borderBottomWidth: 1,
	borderBottomColor: '#ddd',
  },
  welcome: { fontSize: 18, fontWeight: '500' },
  novoChamadoButton: { margin: 10, marginHorizontal: 15 },
  list: { marginTop: 0 },
  loading: { marginTop: 50 },
  errorText: { textAlign: 'center', color: 'red', marginTop: 50, fontSize: 16 },
  emptyText: { textAlign: 'center', color: 'gray', marginTop: 50, fontSize: 16 },
  chamadoItem: {
	backgroundColor: '#fff',
	padding: 15,
	marginVertical: 4,
	marginHorizontal: 10,
	borderRadius: 5,
	borderWidth: 1,
	borderColor: '#ddd',
  },
  itemHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  chamadoTitulo: { fontSize: 16, fontWeight: 'bold', flex: 1 },
  chamadoStatus: {
	fontSize: 12,
	fontWeight: 'bold',
	paddingVertical: 3,
	paddingHorizontal: 6,
	borderRadius: 4,
	overflow: 'hidden',
	alignSelf: 'flex-start',
  },
  chamadoDetalhe: { fontSize: 14, color: '#555' },
});

export default HomeScreen;