import React, { useState, useContext } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, ScrollView } from 'react-native';
import { AuthContext } from '../context/AuthContext';

const RegisterScreen = ({ navigation }) => {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');
  const { registrar } = useContext(AuthContext);

  const handleRegistro = async () => {
	if (!nome || !email || !senha || !confirmarSenha) {
	  Alert.alert('Erro', 'Por favor, preencha todos os campos.');
	  return;
	}
	if (senha !== confirmarSenha) {
	  Alert.alert('Erro', 'As senhas não coincidem.');
	  return;
	}

	try {
	  await registrar(nome, email, senha);
	  Alert.alert(
		'Sucesso!',
		'Usuário registrado. Você já pode fazer o login.',
		[{ text: 'OK', onPress: () => navigation.navigate('Login') }]
	  );
	} catch (error) {
	  Alert.alert('Erro no Registro', error.message);
	}
  };

  return (
	<ScrollView style={styles.container}>
	  <View style={styles.content}>
		<Text style={styles.title}>Criar Nova Conta</Text>
		<Text style={styles.label}>Nome</Text>
		<TextInput
		  style={styles.input}
		  placeholder="Seu nome completo"
		  value={nome}
		  onChangeText={setNome}
		/>
		<Text style={styles.label}>E-mail</Text>
		<TextInput
		  style={styles.input}
		  placeholder="seu@email.com"
		  value={email}
		  onChangeText={setEmail}
		  keyboardType="email-address"
		  autoCapitalize="none"
		/>
		<Text style={styles.label}>Senha</Text>
		<TextInput
		  style={styles.input}
		  placeholder="Crie uma senha"
		  value={senha}
		  onChangeText={setSenha}
		  secureTextEntry
		/>
		<Text style={styles.label}>Confirmar Senha</Text>
		<TextInput
		  style={styles.input}
		  placeholder="Repita sua senha"
		  value={confirmarSenha}
		  onChangeText={setConfirmarSenha}
		  secureTextEntry
		/>
		<View style={styles.buttonContainer}>
		  <Button title="Registrar" onPress={handleRegistro} />
		</View>
		<View style={styles.buttonContainer}>
		  <Button
			title="Já tenho conta (Voltar)"
			onPress={() => navigation.navigate('Login')}
			color="gray"
		  />
		</View>
	  </View>
	</ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  content: { flex: 1, justifyContent: 'center', padding: 20, paddingTop: 50 },
  title: { fontSize: 24, fontWeight: 'bold', textAlign: 'center', marginBottom: 30 },
  label: { fontSize: 16, color: '#333', marginBottom: 5 },
  input: {
	height: 45,
	backgroundColor: '#fff',
	borderColor: 'gray',
	borderWidth: 1,
	marginBottom: 15,
	padding: 10,
	borderRadius: 5,
  },
  buttonContainer: { marginTop: 10 },
});

export default RegisterScreen;