import React, { createContext, useState, useContext, useCallback } from 'react';
import api from '../api/axios';
import { AuthContext } from './AuthContext';

export const ChamadoContext = createContext();

export const ChamadoProvider = ({ children }) => {
  const [chamados, setChamados] = useState([]);
  const [chamadoSelecionado, setChamadoSelecionado] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingSingle, setIsLoadingSingle] = useState(false);
  const [error, setError] = useState(null);
  const { token } = useContext(AuthContext);

  const fetchChamados = useCallback(async () => {
	if (!token) return;
	setIsLoading(true);
	setError(null);
	try {
	  const response = await api.get('/chamados', {
		headers: { Authorization: `Bearer ${token}` },
	  });
	  setChamados(response.data);
	} catch (e) {
	  console.error('Erro ao buscar chamados:', e.response?.data);
	  setError('Não foi possível carregar os chamados.');
	} finally {
	  setIsLoading(false);
	}
  }, [token]);

  const createChamado = async (titulo, descricao, prioridade) => {
	if (!token) return;
	setIsLoading(true);
	setError(null);
	try {
	  await api.post('/chamados', 
		{ titulo, descricao, prioridade },
		{ headers: { Authorization: `Bearer ${token}` } }
	  );
	} catch (e) {
	  console.error('Erro ao criar chamado:', e.response?.data);
	  const errorMsg = e.response?.data?.message || 'Não foi possível criar o chamado.';
	  setError(errorMsg);
	  throw new Error(errorMsg);
	} finally {
	  setIsLoading(false);
	}
  };

  const fetchChamadoById = async (id_chamado) => {
	if (!token) return;
	setIsLoadingSingle(true);
	setError(null);
	try {
	  const response = await api.get(`/chamados/${id_chamado}`, {
		headers: { Authorization: `Bearer ${token}` },
	  });
	  setChamadoSelecionado(response.data);
	} catch (e) {
	  console.error('Erro ao buscar chamado:', e.response?.data);
	  setError('Não foi possível carregar os detalhes do chamado.');
	} finally {
	  setIsLoadingSingle(false);
	}
  };

  const addComentario = async (id_chamado, texto) => {
	if (!token) return;
	try {
	  await api.post(`/chamados/${id_chamado}/comentarios`,
		{ texto },
		{ headers: { Authorization: `Bearer ${token}` } }
	  );
	  await fetchChamadoById(id_chamado);
	} catch (e) {
	  console.error('Erro ao adicionar comentário:', e.response?.data);
	  throw new Error('Falha ao enviar comentário.');
	}
  };

  const updateStatus = async (id_chamado, novo_status) => {
	if (!token) return;
	try {
	  await api.put(`/chamados/${id_chamado}/status`,
		{ novo_status },
		{ headers: { Authorization: `Bearer ${token}` } }
	  );
	  await fetchChamadoById(id_chamado);
	} catch (e) {
	  console.error('Erro ao atualizar status:', e.response?.data);
	  throw new Error('Falha ao atualizar status.');
	}
  };

  const limparChamadoSelecionado = () => {
	setChamadoSelecionado(null);
  };

  return (
	<ChamadoContext.Provider
	  value={{
		chamados,
		chamadoSelecionado,
		isLoading,
		isLoadingSingle,
		error,
		fetchChamados,
		createChamado,
		fetchChamadoById,
		addComentario,
		updateStatus,
		limparChamadoSelecionado,
	  }}>
	  {children}
	</ChamadoContext.Provider>
  );
};